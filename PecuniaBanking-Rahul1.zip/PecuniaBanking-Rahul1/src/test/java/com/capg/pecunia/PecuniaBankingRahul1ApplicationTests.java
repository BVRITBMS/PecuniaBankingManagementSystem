package com.capg.pecunia;

import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.capg.pecunia.dao.ILoanDao;
import com.capg.pecunia.entity.LoanBean;
import com.capg.pecunia.service.ILoanService;
import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
class PecuniaBankingRahul1ApplicationTests {
	@Autowired
	private ILoanService service;
	
	@MockBean
	private ILoanDao dao;
	
	

	@Test
	 public void getAll() {
		when(dao.getAll()).thenReturn(Stream
				.of(new LoanBean(1,123456789,50000,50,800,5),
						new LoanBean(2,789456123,10000,10,900,4)).collect( Collectors.toList()));
		assertEquals(2,service.getAll().size());
	}



	
	@Test
	public void addAccount() {
		LoanBean bean=new LoanBean();
		bean.setAccount_id(1);
		bean.setAccount_num(123456789);
		bean.setAmount(50000);
		bean.setTenure(50);
		bean.setCreditScore(800);
		bean.setRateOfIntrest(5);
	}
		
		
		
		
	}


