package com.capg.pecunia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PecuniaBankingRahul1Application {

	public static void main(String[] args) {
		SpringApplication.run(PecuniaBankingRahul1Application.class, args);
	}

}
