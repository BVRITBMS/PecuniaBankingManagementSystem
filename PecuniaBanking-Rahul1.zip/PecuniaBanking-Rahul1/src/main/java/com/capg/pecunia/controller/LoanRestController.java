package com.capg.pecunia.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.pecunia.entity.LoanBean;
import com.capg.pecunia.service.LoanServiceImpl;
@CrossOrigin(origins = "http://localhost:4200")
@RestController

@RequestMapping(value="/loan")



public class LoanRestController {

	@Autowired
	LoanServiceImpl lsi;
    
/*
 * @author rahul:
 * This method addAccount will insert the details of loan requests
 */
	@PostMapping(value="/create")    
	public ResponseEntity<Boolean> addAccount(@RequestBody LoanBean bean) {
		LoanBean b= lsi.addAccount(bean);
	
		ResponseEntity<Boolean> responseEntity = new ResponseEntity(true, HttpStatus.OK);
		System.out.println("response entity=" + responseEntity);
		return responseEntity;

				
	}
	/*
	 * @author rahul:
	 * This method getAll will show the list of loan request
	 */
	@GetMapping(value="/findall")      
	public ResponseEntity <List<LoanBean>> getAll(){ 

		List<LoanBean> bean = lsi.getAll();
		return new ResponseEntity<List<LoanBean>>(bean,new HttpHeaders(), HttpStatus.OK);
	}
	/*
	 * @author rahul:
	 * This method loanStatus will approve loan request by checking the creditScore using id
	 */
  
	@GetMapping(value="/loanStatus/{id}/{creditScore}") 
	public ResponseEntity<String> loanStatus(@PathVariable("id") int id, @PathVariable("creditScore") int creditScore) throws Exception{
		LoanBean b = lsi.loanStatus(id,creditScore);
		
		if(creditScore<670)
		{

			throw new Exception("Loan is Rejected");
		}

		 
			 ResponseEntity<String>responseEntity = new ResponseEntity<String>("Hello\n" +  b.getAccount_id() + "\n Your Loan  is Approved " + "\n Your Account Number is " +b.getAccount_num() , HttpStatus.OK);
			 return responseEntity;
					 
			 }
			 

		 
		

	}
	

