package com.capg.pecunia.service;



import java.util.List;

import com.capg.pecunia.entity.AccountBean;



public interface IAccountService {
	public AccountBean addAccount(AccountBean account);
	public List<AccountBean> getAll();
	
	/*
	 * public boolean validateName(String customerName) ; public boolean
	 * validatePan(String customerPan); public boolean validateContact(String
	 * customerContact); public boolean validateAadhar(String customerAadhar);
	 * public boolean validateDateOfBirth(String dob); public boolean
	 * validatePin(String pin);
	 */
}



