package com.capg.pecunia.entity;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
@Entity
@Table(name="Account")

public class AccountBean {
	@Id
	@NotEmpty(message="please provide the account number")

	private String accountNumber;
    @NotEmpty(message="please provide the customer name")
	private String customerName;
	//@NotEmpty(message="please provide the accountBalance")
	private  double accountBalance;
	@NotEmpty(message="please provide the customerContact")
	private String customerContact;
	@NotEmpty(message="please provide the customer Aadhar")
	
	private  String customerAadhar;
	@NotEmpty(message="please provide the customer address")
	private String addressline1;
	@NotEmpty(message="please provide the customer address")
	private String addressline2;
	@NotEmpty(message="please provide the customer city")
	private String city;
	@NotEmpty(message="please provide the customer state")
	private String state;
	@NotEmpty(message="please provide the customer country")
	private String country;
	@NotEmpty(message="please provide the customer zipcode")
	private String zipcode;
	
	
	public String getAddressline1() {
		return addressline1;
	}
	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}
	public String getAddressline2() {
		return addressline2;
	}
	public void setAddressline2(String addressline2) {
		this.addressline2 = addressline2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getCustomerAadhar() {
		return customerAadhar;
	}
	public void setCustomerAadhar(String customerAadhar) {
		this.customerAadhar = customerAadhar;
	}

	
	public String getCustomerContact() {
		return customerContact;
	}
	public void setCustomerContact(String customerContact) {
		this.customerContact = customerContact;
	}
	public AccountBean()
	{
		super();
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	@Override
	public String toString() {
		return "AccountBean [accountNumber=" + accountNumber + ", customerName=" + customerName + ", accountBalance="
				+ accountBalance + ", customerAadhar=" + customerAadhar  + ", customerContact=" + customerContact +  ", addressline1=" + addressline1 + ", addressline2=" + addressline2 + ", city="
				+ city + ", state=" + state + ", country=" + country + ", zipcode=" + zipcode + "]";
	}
	
	
}
	