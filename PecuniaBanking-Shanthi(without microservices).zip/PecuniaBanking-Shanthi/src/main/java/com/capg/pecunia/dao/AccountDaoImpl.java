package com.capg.pecunia.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;


import com.capg.pecunia.entity.AccountBean;
@Repository
@Transactional
public class AccountDaoImpl implements IAccountDao {
	
	@PersistenceContext
	EntityManager entityManager;
	/** 
	 * @author Shanthi sree:
	 * this method addAccount will insert details into entity of AccountBean **/
	@Override
	public AccountBean addAccount(AccountBean bean) {
		entityManager.persist(bean);
		return bean;
	}

/** 
 * @author Shanthi sree:
 * this method getAll will retrieve all the accounts **/
	@Override
	public List<AccountBean> getAll() {
		Query q = entityManager.createQuery("select e from AccountBean e");
	    List<AccountBean> list=q.getResultList();
		return list;
	}

}