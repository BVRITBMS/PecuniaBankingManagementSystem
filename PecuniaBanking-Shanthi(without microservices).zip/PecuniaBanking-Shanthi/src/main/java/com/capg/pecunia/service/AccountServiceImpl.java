package com.capg.pecunia.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import com.capg.pecunia.dao.IAccountDao;
import com.capg.pecunia.entity.AccountBean;
@Service
public class AccountServiceImpl implements IAccountService {
@Autowired
IAccountDao dao;

/** 
 * @author Shanthi sree:
 * this method addAccount will insert details into entity of AccountBean **/
@Override	
public AccountBean addAccount(AccountBean bean ) {
	return dao.addAccount(bean);
}


/** 
 * @author Shanthi sree:
 * this method getAll will retrieve all the accounts **/
public List<AccountBean> getAll() {
	
	return dao.getAll();
	
}
}
