package com.capg.pecunia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PecuniaBankingShanthiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PecuniaBankingShanthiApplication.class, args);
		System.out.println("hi");
	}

}
