package com.capg.pecunia;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
//import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.capg.pecunia.dao.IAccountDao;
import com.capg.pecunia.entity.AccountBean;
import com.capg.pecunia.service.IAccountService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PecuniaBankingShanthiApplicationTests {
	
	
@Autowired
    IAccountService accountservice;
@Test
void TestfindAll() {
	List<AccountBean> accountlist = accountservice.getAll();
	assertEquals(accountlist.size(), 4);

}


}


