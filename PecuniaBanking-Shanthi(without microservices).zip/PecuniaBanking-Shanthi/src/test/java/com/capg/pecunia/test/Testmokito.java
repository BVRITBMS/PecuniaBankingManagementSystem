package com.capg.pecunia.test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.capg.pecunia.dao.IAccountDao;
import com.capg.pecunia.entity.AccountBean;
import com.capg.pecunia.service.IAccountService;

public class Testmokito {

	@Autowired
	IAccountService accountservice;
	
	@MockBean
	IAccountDao accountDao;
	@Test
	public void addAccount()
	{
		AccountBean bean= new AccountBean();
		bean.setAccountBalance(2000.00);
		bean.setAccountNumber("123112");
		bean.setAddressline1("78/2,kazipet");
		bean.setAddressline2("warangal");
		bean.setCity("kazipet");
		bean.setCountry("India");
		bean.setCustomerAadhar("23142656172671");
	    bean.setCustomerContact("2837153627");
	    bean.setCustomerName("rita");
	    bean.setState("telangana");
	    bean.setZipcode("678643");

	Mockito.when(accountDao.addAccount(bean)).thenReturn(bean);
	assertThat(accountservice.addAccount(bean)).isEqualTo(bean);
	}
}
